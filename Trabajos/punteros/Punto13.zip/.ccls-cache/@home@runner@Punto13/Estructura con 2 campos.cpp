#include <iostream>
#include <string>

using namespace std;

struct Persona {
  string nombre;
  int edad;
};

int main() {
  // Declaración de la estructura
  Persona persona = {"Juan Pérez", 25};

  // Impresión de los campos
  cout << "Nombre: " << persona.nombre << endl;
  cout << "Edad: " << persona.edad << endl;
  return 0;
}
