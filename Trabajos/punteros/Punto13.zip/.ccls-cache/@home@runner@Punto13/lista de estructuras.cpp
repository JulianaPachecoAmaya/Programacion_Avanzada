#include <iostream>
#include <string>
#include <vector>

using namespace std;

struct Persona {
  string nombre;
  int edad;
};

int main() {
  // Declaración
