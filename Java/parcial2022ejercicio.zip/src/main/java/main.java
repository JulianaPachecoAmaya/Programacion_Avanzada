public class main{
  public static void main(String[] args) {
    Pasajero pasajero1= new Pasajero ("Juliana", "Pacheco", "JR-123", "A1", 19);
    Pasajero pasajero2= new Pasajero ("Juan", "Perez", "JR-456", "A2", 20);

    pasajero1.MenorEdad(pasajero1, pasajero2);
  }

  
}